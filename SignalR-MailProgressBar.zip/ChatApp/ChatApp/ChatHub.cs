﻿using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Threading;
namespace ChatApp
{
    public class ChatHub : Hub
    {
        public async Task SendMail()
        {
            int mailCount = 30;
            await Clients.All.SendAsync("ReceiveStatus", "Processing "+mailCount +" mails", "0");
            await Task.Delay(1000);
            for (int i = 0; i <= mailCount; i++)
            {
                int percentage = (int)(i * 100) / mailCount;
                await Task.Delay(1000);
                await Clients.All.SendAsync("ReceiveStatus", i + " mails sent", percentage);

            }
            await Clients.All.SendAsync("ReceiveStatus", "Completed", "100");
        }
    }
}
