﻿const connection = new signalR.HubConnectionBuilder()
    .withUrl("/chatHub")
    .build();

//This method receive the message and Append to our list
connection.on("ReceiveStatus", (status,percentage) => {
    console.log(status);
    $("#messagesList").html(status);
    $(".progress-bar").css("width", percentage + "%");
    $("#mail-percentage").html(percentage + "%");
});

connection.start().catch(err => console.error(err.toString()));
//Send the message
document.getElementById("sendMail").addEventListener("click", event => {
    connection.invoke("SendMail").catch(err => console.error(err.toString()));
    event.preventDefault();
});